# MarketIntel PRO — Instalación en GitHub Pages

## Archivos incluidos
- index.html      → La app completa
- manifest.json   → Configuración PWA
- sw.js           → Service Worker (offline + notificaciones)
- icon-192.png    → Ícono app
- icon-512.png    → Ícono alta resolución
- INSTRUCCIONES.md → Este archivo

---

## PASO 1 — Crear cuenta GitHub (si no tenés)
1. Andá a https://github.com
2. Click en "Sign up"
3. Elegí un nombre de usuario (ej: gastondario)
4. Email, contraseña → crear cuenta
5. Verificá tu email

---

## PASO 2 — Crear el repositorio
1. En GitHub, click en el "+" arriba a la derecha
2. "New repository"
3. Repository name: marketintel-pro
4. Dejalo en "Public"
5. Click "Create repository"

---

## PASO 3 — Subir los archivos
En la página del repositorio vacío:
1. Click en "uploading an existing file"
2. Arrastrá TODOS los archivos de esta carpeta:
   - index.html
   - manifest.json
   - sw.js
   - icon-192.png
   - icon-512.png
3. Abajo en "Commit changes" → click "Commit changes"

---

## PASO 4 — Activar GitHub Pages
1. En tu repositorio → click en "Settings" (arriba)
2. En el menú izquierdo → "Pages"
3. En "Source" → seleccioná "Deploy from a branch"
4. Branch: "main" → folder: "/ (root)"
5. Click "Save"
6. Esperá 2-3 minutos

---

## PASO 5 — Tu URL pública
GitHub te da una URL así:
https://TU-USUARIO.github.io/marketintel-pro

Ejemplo:
https://gastondario.github.io/marketintel-pro

---

## PASO 6 — Instalar en el teléfono

### iPhone (Safari):
1. Abrí la URL en Safari
2. Botón compartir ⬆️ → "Agregar a pantalla de inicio"
3. Nombre: MarketIntel PRO → Agregar

### Android (Chrome):
1. Abrí la URL en Chrome
2. Tres puntitos ⋮ → "Instalar app" o "Agregar a pantalla de inicio"
3. Chrome puede mostrar un banner automático de instalación

---

## Resultado final
- Ícono en tu pantalla de inicio como app nativa
- Funciona sin internet (datos en caché)
- Notificaciones push activadas en Android
- URL pública que podés compartir

---

## Actualizar la app en el futuro
Cuando quieras actualizar:
1. Entrá a tu repositorio en GitHub
2. Click en index.html → ícono del lápiz ✏️
3. Pegá el nuevo código → "Commit changes"
4. En 2 minutos se actualiza automáticamente
